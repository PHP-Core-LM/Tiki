-- func get all user
CREATE function [dbo].[fc_getAllUser] ()
returns @KetQua table (
	MaKH varchar(255),
	TenKH nvarchar(255))
as
begin
	insert into @KetQua
		select TenDangNhap, TenTaiKhoan from CT_Account where MaChucVu='cv02'
	return;
end
go

