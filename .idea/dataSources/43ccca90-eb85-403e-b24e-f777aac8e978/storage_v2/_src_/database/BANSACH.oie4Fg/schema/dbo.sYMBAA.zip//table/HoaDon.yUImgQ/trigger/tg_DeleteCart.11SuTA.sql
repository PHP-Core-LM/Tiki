Create Trigger tg_DeleteCart On dbo.HoaDon After Delete
As
Begin
	Declare @MaHoaDon varchar(10);
	Select @MaHoaDon = MaHoaDon From deleted

	Delete From CT_HoaDon
		Where MaHoaDon = @MaHoaDon
End
go

