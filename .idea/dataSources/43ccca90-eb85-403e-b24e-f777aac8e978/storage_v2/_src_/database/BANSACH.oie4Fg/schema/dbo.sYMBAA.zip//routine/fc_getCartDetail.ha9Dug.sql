
Create Function fc_getCartDetail(@MaHoaDon varchar(10)) Returns @KetQua Table(
	MaSach varchar(10),
	SoLuong int,
	Gia int
)
As
Begin
	Insert Into @KetQua
		Select hd.MaSach, hd.Soluong, hd.Gia From CT_HoaDon hd Where MaHoaDon = @MaHoaDon
	Return;
End
go

