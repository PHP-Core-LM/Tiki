CREATE proc InsertAccount (
@TenDangNhap varchar(10),
@MatKhau varchar(50),
@TenTaiKhoan varchar(255),
@GioiTinh nvarchar(5),
@NgaySinh date,
@DiaChi varchar(255),
@Email varchar(50),
@SDT varchar(13)
)
as
	Begin 
				if(@TenDangNhap is not null and @MatKhau is not null and @TenTaiKhoan is not null and @GioiTinh is not null
				and @NgaySinh is not null and @DiaChi is not null and @SDT is not null and @Email is not null)
				begin
						declare @sex bit;
						if(@GioiTinh='Nam') set @sex=1 
						else set @sex=0;
						insert into Account(TenDangNhap,MatKhau) values(@TenDangNhap,@MatKhau)
						insert into CT_Account(TenDangNhap,TenTaiKhoan,MaChucVu,GioiTinh,NgaySinh,DiaChi,SDT,Email)
						values(@TenDangNhap,@TenTaiKhoan,'cv02',@sex,@NgaySinh,@DiaChi,@SDT,@Email)
				end
	End
go

