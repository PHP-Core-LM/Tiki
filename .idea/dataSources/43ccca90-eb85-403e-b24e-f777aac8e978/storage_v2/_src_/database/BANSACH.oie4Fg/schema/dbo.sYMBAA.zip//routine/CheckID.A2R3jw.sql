
create function CheckID(
@Tendangnhap varchar(10)
)
returns int
as
begin
	declare @temp int;
	select @temp=Count(*) from Account where TenDangNhap=@Tendangnhap
	return @temp
end

go

