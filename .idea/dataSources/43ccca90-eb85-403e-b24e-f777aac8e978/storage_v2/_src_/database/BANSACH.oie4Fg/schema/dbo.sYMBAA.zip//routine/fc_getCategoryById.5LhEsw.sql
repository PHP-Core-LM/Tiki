


-->Lấy tên thể loại
Create Function fc_getCategoryById(@MaTheLoai varchar(10)) Returns nvarchar(255)
As
Begin
	Declare @TenTheLoai nvarchar(255) = null;
	Select @TenTheLoai = TenTheLoai From TheLoai Where MaTheLoai = @MaTheLoai
	return @TenTheLoai;
End
go

