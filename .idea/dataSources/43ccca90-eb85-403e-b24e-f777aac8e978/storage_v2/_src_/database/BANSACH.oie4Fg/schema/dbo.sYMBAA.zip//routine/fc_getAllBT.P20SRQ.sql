CREATE function [dbo].[fc_getAllBT]()
returns @KetQua table(
MaTin int,
NoiDung nvarchar(MAX),
Anh varchar(MAX),
TieuDe nvarchar(MAX)
)
as
begin
	insert into @KetQua
		select * from BangTin
	return;
end
go

