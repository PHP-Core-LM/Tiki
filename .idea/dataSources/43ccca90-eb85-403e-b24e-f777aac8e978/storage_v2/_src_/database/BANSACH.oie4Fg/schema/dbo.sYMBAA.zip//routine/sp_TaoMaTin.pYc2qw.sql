create Procedure [dbo].[sp_TaoMaTin]
	@MaTin int output
As
Begin
	Declare @CountRow int;

	-->Đếm số lượng dòng đã có trong bảng
	Select @CountRow = Max(MaTin) From BangTin

	-->Tạo Mã NXB mới theo số lượng dòng đã có
	Set @MaTin = @CountRow+1;
End
go

