create Function [dbo].[fc_getBookCateById](@MaSach varchar(10)) Returns nvarchar(50)
As
Begin
	Declare @TenTheLoai nvarchar(255) = null;
	Select @TenTheLoai = [dbo].fc_getCategoryById(MaTheLoai) From Books Where MaSach = @MaSach
	return @Tentheloai;
End
go

