CREATE proc [dbo].[sp_setTT]
	@MaHoaDon varchar(10)
as
begin
	declare @TinhTrang varchar(10)
	select @TinhTrang= TinhTrang from HoaDon where MaHoaDon=@MaHoaDon
	if(@TinhTrang='TT1')
		update HoaDon
		set TinhTrang='TT2'
		where MaHoaDon=@MaHoaDon
	else
		if(@TinhTrang='TT2')
		update HoaDon
		set TinhTrang='TT4'
		where MaHoaDon=@MaHoaDon
		else
			if(@TinhTrang='TT4')
			update HoaDon
			set TinhTrang='TT5'
			where MaHoaDon=@MaHoaDon	

end
go

