CREATE Function [dbo].[fc_getBookTT](@MaSach varchar(10) ) 
Returns @KetQua Table(
	MaSach varchar(10),
	TenSach nvarchar(255),
	GiaBan int,
	TenTheLoai nvarchar(255),
	TenNXB nvarchar(255),
	TenTacGia nvarchar(255),
	MoTa ntext,
	DanhGia real
)
As
Begin
	declare @MaTheLoai varchar(10)
	declare @TenTuongTu nvarchar(255)
	select @MaTheLoai=MaTheLoai from Books where @MaSach=MaSach
	select @TenTuongTu=SUBSTRING(TenSach,1,5) from Books where @MaSach=MaSach
	Insert Into @KetQua
		select TOP(5) MaSach, TenSach, GiaBan, [dbo].fc_getCategoryById(MaTheLoai), [dbo].fc_getNxbById(MaNXB), 
			[dbo].fc_getAuthorById(MaTacGia), MoTa, DanhGia from V_RandBook where @TenTuongTu like TenSach or MaTheLoai=@MaTheLoai
	Return;
End
go

