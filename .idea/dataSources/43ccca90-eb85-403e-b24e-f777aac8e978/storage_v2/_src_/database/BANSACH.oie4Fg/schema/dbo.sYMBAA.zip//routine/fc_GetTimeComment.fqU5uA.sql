
CREATE Function [dbo].[fc_GetTimeComment](@ThoiGianBinhLuan datetime) Returns varchar(8)
As
Begin
	Declare @TimeLv1 int = dbo.fc_GetTimeCommentLv1(@ThoiGianBinhLuan);
	If (@TimeLv1 <= 0)
	Begin
		Declare @TimeLv2 varchar(8) = dbo.fc_GetTimeCommentLv2(@ThoiGianBinhLuan);
		Return @TimeLv2;
	End
	Return @TimeLv1;
End
go

