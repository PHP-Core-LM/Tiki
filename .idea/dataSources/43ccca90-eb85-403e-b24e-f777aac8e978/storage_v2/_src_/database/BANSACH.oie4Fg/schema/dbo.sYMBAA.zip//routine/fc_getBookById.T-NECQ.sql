-->Lấy thông tin sách
CREATE Function [dbo].[fc_getBookById](@MaSach varchar(10)) Returns @KetQua Table (
	MaSach varchar(10),
	TenSach nvarchar(255),
	GiaBan int,
	TenTheLoai nvarchar(255),
	TenNXB nvarchar(255),
	TenTacGia nvarchar(255),
	MoTa ntext,
	DanhGia real
)
As
Begin
	Declare @MaTheLoai varchar(10), @MaNXB varchar(10), @MaTacGia varchar(10);
	Insert Into @KetQua(MaSach, TenSach, GiaBan, MoTa, DanhGia)
		Select MaSach, TenSach, GiaBan, MoTa, DanhGia From Books b Where MaSach = @MaSach

	Select @MaTheLoai = MaTheLoai, @MaNXB = MaNXB, @MaTacGia = MaTacGia From Books Where MaSach = @MaSach
	Update @KetQua Set 
		TenTheLoai = [dbo].fc_getCategoryById(@MaTheLoai),
		TenNXB = [dbo].fc_getNxbById(@MaNXB),
		TenTacGia = [dbo].fc_getAuthorById(@MaTacGia)
	Where MaSach = @MaSach;

	Return;
End
go

