
CREATE Procedure sp_AddBookToCart(@MaSach varchar(10), @MaHoaDon varchar(10), @SoLuong int, @Gia int)
As
Begin
	Insert Into CT_HoaDon Values(@MaSach, @MaHoaDon, @SoLuong, @Gia);
	Return;
End
go

