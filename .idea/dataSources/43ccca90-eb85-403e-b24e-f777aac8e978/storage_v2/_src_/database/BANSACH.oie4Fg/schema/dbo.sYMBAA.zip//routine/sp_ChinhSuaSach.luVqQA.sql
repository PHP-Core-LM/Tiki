
CREATE Procedure sp_ChinhSuaSach
	@MaSach varchar(10),
	@TenSach nvarchar(255), 
	@Gia int, 
	@TheLoai nvarchar(50), 
	@NXB nvarchar(50), 
	@TacGia nvarchar(50), 
	@MoTa ntext
As
Begin
	Declare @MaTheLoai_Moi varchar(10), @MaTheLoai_Cu varchar(10), 
		@MaNXB_Moi varchar(10), @MaNXB_Cu varchar(10), 
		@MaTacGia_Moi varchar(10), @MaTacGia_Cu varchar(10);

	-->Mã NXB
	Select @MaNXB_Moi = NXB.MaNXB From NXB Where @NXB = NXB.TenNXB;
	Select @MaNXB_Cu = b.MaNXB From Books b Where @MaSach = b.MaSach;

	-->Mã Thể loại
	Select @MaTheLoai_Moi = tl.MaTheLoai From TheLoai tl Where @TheLoai = tl.TenTheLoai;
	Select @MaTheLoai_Cu = b.MaTheLoai From Books b Where @MaSach = b.MaSach;

	-->Mã tác giả
	Select @MaTacGia_Moi = au.MaTacGia From TacGia au Where @TacGia = au.TenTacGia;
	Select @MaTacGia_Cu = b.MaTacGia From Books b Where @MaSach = b.MaSach;

	-->Kiểm tra thay đổi dữ liệu của khóa ngoại, đảm bảo mã mới phải khác null
	if (@MaNXB_Moi Is Null) Exec sp_ThemNXB @MaNXB_Moi output, @NXB;
	if (@MaTacGia_Moi Is Null) Exec sp_ThemTacGia @MaTacGia_Moi output, @TacGia;
	if (@MaTheLoai_Moi Is Null) Exec sp_ThemTheLoai @MatheLoai_Moi output, @TheLoai;

	-->Tiến hành update
	Update Books Set TenSach = @TenSach, GiaBan = @Gia, MaTheLoai = @MaTheLoai_Moi,
			MaNXB = @MaNXB_Moi, MaTacGia = @MaTacGia_Moi
		Where MaSach = @MaSach;
End
go

