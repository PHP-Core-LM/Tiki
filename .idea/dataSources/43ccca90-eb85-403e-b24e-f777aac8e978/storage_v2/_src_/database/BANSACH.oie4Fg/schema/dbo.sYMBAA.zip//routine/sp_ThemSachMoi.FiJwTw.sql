-->Thêm sách mới vào db, thông tin truyền vào chưa tối giản
CREATE Procedure sp_ThemSachMoi
	@MaSach varchar(10) output,
	@TenSach nvarchar(255), 
	@Gia int, 
	@TheLoai nvarchar(50), 
	@NXB nvarchar(50), 
	@TacGia nvarchar(50), 
	@MoTa ntext
As
Begin
	Declare @MaNXB varchar(10) = null, @MaTheLoai varchar(10) = null, @MaTacGia varchar(10) = null;
	Select @MaNXB = NXB.MaNXB From NXB Where @NXB = NXB.TenNXB;
	Select @MaTheLoai = tl.MaTheLoai From TheLoai tl Where @TheLoai = tl.TenTheLoai;
	Select @MaTacGia = au.MaTacGia From TacGia au Where @TacGia = au.TenTacGia;

	if (@MaNXB is Null) Exec sp_ThemNXB @MaNXB output, @NXB;
	if (@MaTheLoai is Null) Exec sp_ThemTheLoai @MaTheLoai output, @TheLoai;
	if (@MaTacGia is Null) Exec sp_ThemTacGia @MaTacGia output, @TacGia;

	Exec sp_TaoMaSach @MaSach output;
	Exec sp_ThemSach @MaSach, @TenSach, @Gia, @MaTheLoai, @MaNXB, @MaTacGia, @MoTa;
End
go

