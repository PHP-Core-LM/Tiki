CREATE PROCEDURE [dbo].[sp_ChinhSuaDanhGiaSach](@MaSach varchar(10), @DanhGiaMoi real)
AS
BEGIN
	Declare @DanhGiaCu real;
	Select @DanhGiaCu = DanhGia From Books Where MaSach = @MaSach
	Set @DanhGiaMoi = (@DanhGiaMoi + @DanhGiaCu)/2;
	Update Books Set DanhGia = @DanhGiaMoi
		Where MaSach = @MaSach
END
go

