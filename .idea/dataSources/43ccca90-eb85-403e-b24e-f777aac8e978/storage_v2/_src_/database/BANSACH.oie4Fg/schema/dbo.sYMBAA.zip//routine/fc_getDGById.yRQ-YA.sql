create Function [dbo].[fc_getDGById](@MaSach varchar(10)) Returns real
As
Begin
	Declare @DanhGia real;
	Select @DanhGia = DanhGia From Books Where MaSach = @MaSach
	return @DanhGia;
End
go

