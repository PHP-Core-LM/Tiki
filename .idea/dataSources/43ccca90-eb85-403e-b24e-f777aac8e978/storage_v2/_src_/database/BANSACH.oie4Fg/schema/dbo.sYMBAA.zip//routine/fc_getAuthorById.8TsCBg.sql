


-->Lấy tên tác giả
Create Function fc_getAuthorById(@MaTacGia varchar(10)) Returns nvarchar(255)
As
Begin
	Declare @TenTacGia nvarchar(255) = null;
	Select @TenTacGia = TenTacGia From TacGia Where MaTacGia = @MaTacGia
	return @TenTacGia;
End
go

