CREATE proc [dbo].[sp_ThemTin]
	@MaTin int output,
	@NoiDung nvarchar(MAX),
	@Anh varchar(MAX),
	@TieuDe nvarchar(MAX)
as
begin
	exec sp_TaoMaTin @MaTin output;
	insert into BangTin values (@MaTin, @NoiDung, @Anh, @TieuDe);
end
go

