create proc [dbo].[sp_delBT]
	@MaTin varchar(10)
as
begin
	delete from BangTin where MaTin=@MaTin
end
go

