CREATE view [dbo].[v_TOPDG]
as
	select TOP(255) * from Books order by DanhGia DESC;
go

