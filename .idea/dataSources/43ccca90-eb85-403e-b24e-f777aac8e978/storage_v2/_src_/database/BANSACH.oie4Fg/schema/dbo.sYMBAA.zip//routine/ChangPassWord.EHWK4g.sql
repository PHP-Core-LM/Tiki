create proc ChangPassWord
(
@TenTK varchar(10),
@Password varchar(50)
)
as
begin
	Update Account
	set MatKhau=@Password
	where TenDangNhap=@TenTK
end
go

