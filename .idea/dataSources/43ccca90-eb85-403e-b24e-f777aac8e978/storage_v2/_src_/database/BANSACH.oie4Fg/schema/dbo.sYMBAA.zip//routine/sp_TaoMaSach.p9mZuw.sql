CREATE Procedure sp_TaoMaSach
	@MaSach varchar(10) output
As
Begin
	Declare @CountRow int;

	-->Đếm số lượng dòng đã có trong bảng
	Select @CountRow = COUNT(MaSach) From Books

	-->Tạo Mã NXB mới theo số lượng dòng đã có
	Set @MaSach = 's' + RIGHT('00000' + CAST((@CountRow + 1) As varchar(5)), 5);
End
go

