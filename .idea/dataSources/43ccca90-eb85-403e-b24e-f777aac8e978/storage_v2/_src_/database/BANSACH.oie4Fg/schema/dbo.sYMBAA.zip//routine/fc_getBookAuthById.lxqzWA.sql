create Function [dbo].[fc_getBookAuthById](@MaSach varchar(10)) Returns nvarchar(50)
As
Begin
	Declare @TacGia nvarchar(255) = null;
	Select @TacGia = [dbo].fc_getAuthorById(MaTacGia) From Books Where MaSach = @MaSach
	return @TacGia;
End
go

