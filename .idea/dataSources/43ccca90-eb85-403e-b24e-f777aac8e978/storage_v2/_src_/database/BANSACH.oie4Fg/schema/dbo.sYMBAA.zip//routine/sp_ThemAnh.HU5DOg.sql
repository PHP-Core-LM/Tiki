-->Thêm ảnh mới vào db
CREATE Procedure sp_ThemAnh
	@MaAnh varchar(10) output,
	@MaSach varchar(10),
	@DuongDan varchar(50)
As
Begin
	Declare @CountRow int;

	-->Đếm số lượng dòng đã có trong bảng
	Select @CountRow = COUNT(MaAnh) From [Image]

	-->Tạo Mã NXB mới theo số lượng dòng đã có
	Select @MaAnh = 'img' + RIGHT('00000' + CAST((@CountRow + 1) As varchar(5)), 5);

	Insert Into [Image]
		Values(@MaAnh, @MaSach, @DuongDan);
End
go

