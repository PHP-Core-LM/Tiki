-- func search user
CREATE function [dbo].[fc_getSearchUser](@searchU nvarchar(255))
returns @KetQua table(
TenDangNhap nvarchar(255),
TenTaikhoan nvarchar(255)
)
as
begin
	insert into @KetQua
		select TenDangNhap, TenTaiKhoan from CT_Account where TenDangNhap like '%'+@SearchU+'%' or dbo.fuChuyenCoDauThanhKhongDau(TenTaiKhoan) like '%'+@SearchU+'%'
	return;
end
go

