-- 1(true) là nam, 2(false) là nữ
CREATE Function [dbo].[fc_getSex](@GioiTinh bit) Returns nvarchar(4)
As
Begin
	Declare @Sex nvarchar(4) = null;
	Select @GioiTinh = @GioiTinh From Account
	if @GioiTinh=1
		set @Sex='Nam'
	else
		set @Sex=N'Nữ'
	return @Sex;
End
go

