
CREATE Function [dbo].[fc_GetNameOfAccount](@TenDangNhap varchar(10)) Returns nvarchar(255)
As
Begin
	Declare @TenTaiKhoan nvarchar(255);
	Select @TenTaiKhoan = TenTaiKhoan From CT_Account Where @TenDangNhap = TenDangNhap
	If (@TenTaiKhoan IS NULL) Set @TenTaiKhoan = 'unknown';
	Return @TenTaiKhoan;
End
go

