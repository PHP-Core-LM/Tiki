
Create Function fc_Login(@TenDangNhap varchar(10), @MatKhau varchar(50)) Returns bit
As
Begin
	Declare @Result bit;
	If (Exists (Select * From Account Where TenDangNhap = @TenDangNhap And MatKhau = @MatKhau))
		Set @Result = 1;
	Else
		Set @Result = 0;

	Return @Result;
End
go

