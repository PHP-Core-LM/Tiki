
CREATE Function fc_GetTimeCommentLv2(@ThoiGianBinhLuan datetime) Returns varchar(8)
As
Begin
	Declare @KhoangCach int, @ThoiGianHienTai datetime;
	Select @KhoangCach = ABS(DATEDIFF(SECOND, Convert(Time, @ThoiGianBinhLuan), Convert(Time, GETDATE())));
	
	Declare @Time varchar(8), @Gio int, @Phut int, @Giay int;
	Set @Gio = @KhoangCach/3600;
	Set @KhoangCach = @KhoangCach - @Gio*3600;
	Set @Phut = @KhoangCach/60;
	Set @Giay = @KhoangCach - @Phut*60;
	Set @Time = Right('00' + Convert(varchar, @Gio), 2) + ':' + Right('00' + Convert(varchar, @Phut), 2) + ':' + Right('00' + Convert(varchar, @Giay), 2);
	Return @Time;
End
go

