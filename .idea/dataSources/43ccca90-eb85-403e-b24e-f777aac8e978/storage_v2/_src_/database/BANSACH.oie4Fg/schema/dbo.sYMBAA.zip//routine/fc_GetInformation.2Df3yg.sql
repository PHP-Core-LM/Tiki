
CREATE Function [dbo].[fc_GetInformation](@TenDangNhap varchar(10)) Returns @KetQua Table(
	TenTaiKhoan nvarchar(255),
	ChucVu nvarchar(30),
	GioiTinh bit,
	NgaySinh date,
	DiaChi nvarchar(255),
	Sdt nvarchar(13),
	Email varchar(50)
)
As
Begin
	Insert Into @KetQua
		Select TenTaiKhoan, TenChucVu, GioiTinh, NgaySinh, DiaChi, SDT, Email From CT_Account acc, ChucVu cv
			Where acc.TenDangNhap = @TenDangNhap And acc.MaChucVu = cv.MaChucVu 
	Return;
End
go

