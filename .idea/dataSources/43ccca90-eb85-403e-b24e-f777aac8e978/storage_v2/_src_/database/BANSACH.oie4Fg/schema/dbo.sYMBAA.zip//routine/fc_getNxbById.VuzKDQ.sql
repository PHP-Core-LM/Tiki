


-->Lấy tên nxb
Create Function fc_getNxbById(@MaNXB varchar(10)) Returns nvarchar(255)
As
Begin
	Declare @TenNXB nvarchar(255) = null;
	Select @TenNXB = TenNXB From NXB Where MaNXB = @MaNXB
	return @TenNXB;
End
go

