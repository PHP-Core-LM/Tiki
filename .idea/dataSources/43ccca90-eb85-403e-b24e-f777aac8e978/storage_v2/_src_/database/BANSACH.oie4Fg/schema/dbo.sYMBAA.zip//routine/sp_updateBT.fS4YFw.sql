create proc [dbo].[sp_updateBT]
	@MaTin varchar(10),
	@NoiDung nvarchar(MAX),
	@Anh varchar(MAX),
	@TieuDe nvarchar(MAX)
as
begin
	update BangTin
	set NoiDung=@NoiDung, Anh=@Anh, TieuDe=@TieuDe
	where MaTin=@MaTin
end
go

