
Create Procedure sp_Signup(@TenDangNhap varchar(10), @MatKhau varchar(50), @TenTaiKhoan nvarchar(255), @Email varchar(50))
As
Begin
	Insert Into Account Values(@TenDangNhap, @MatKhau, @Email);
	Insert Into CT_Account Values(@TenDangNhap, @TenTaiKhoan, 'cv02');
	Return;
End
go

