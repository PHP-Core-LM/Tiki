CREATE Function [dbo].[fc_getStateById](@MaTinhTrang varchar(10)) Returns nvarchar(255)
As
Begin
	Declare @TinhTrang nvarchar(255) = null;
	Select @TinhTrang = TinhTrang From TinhTrang Where MaTinhTrang = @MaTinhTrang
	return @TinhTrang;
End

go

