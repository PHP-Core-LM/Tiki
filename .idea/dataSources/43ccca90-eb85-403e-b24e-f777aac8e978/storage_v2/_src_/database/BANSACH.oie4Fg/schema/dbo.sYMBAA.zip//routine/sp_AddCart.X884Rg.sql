CREATE Procedure [dbo].[sp_AddCart](@MaHoaDon varchar(10) output, @MaTaiKhoan varchar(10), @TenNguoiMua ntext, @DiaChi ntext, @SDT varchar(11), @Email varchar(50))
As
Begin
	Set @MaHoaDon = dbo.fc_CreateCartId();
	Declare @NgayIn datetime = GETDATE(), @TinhTrang varchar(10) = 'TT1';
	Insert Into HoaDon Values(@MaHoaDon, @TinhTrang, @NgayIn, @MaTaiKhoan, @TenNguoiMua, @DiaChi, @SDT, @Email);
	return;
End
go

