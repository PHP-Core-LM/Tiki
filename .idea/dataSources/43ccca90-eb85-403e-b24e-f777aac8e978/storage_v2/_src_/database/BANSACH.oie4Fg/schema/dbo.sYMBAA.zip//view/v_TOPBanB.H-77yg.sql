CREATE view [dbo].[v_TOPBanB]
as
	select TOP(255) vt.MaSach,vt.SL, B.TenSach, B.GiaBan,B.MaTheLoai,B.MaNXB,B.MaTacGia,B.MoTa,B.DanhGia from Books B, v_TOPBan vT where vT.MaSach=B.MaSach;
go

