-- func searchbook
CREATE Function [dbo].[fc_getSearchBook](@search nvarchar(255) ) 
Returns @KetQua Table(
	MaSach varchar(10),
	TenSach nvarchar(255),
	GiaBan int,
	TenTheLoai nvarchar(255),
	TenNXB nvarchar(255),
	TenTacGia nvarchar(255),
	MoTa ntext,
	DanhGia real
)
As
Begin
	Insert Into @KetQua
		select MaSach, TenSach, GiaBan, [dbo].fc_getCategoryById(MaTheLoai), [dbo].fc_getNxbById(MaNXB), 
			[dbo].fc_getAuthorById(MaTacGia), MoTa, DanhGia from Books where TenSach like '%'+@search+'%' or dbo.fuChuyenCoDauThanhKhongDau(TenSach) like '%'+@search+'%'
	Return;
End
go

