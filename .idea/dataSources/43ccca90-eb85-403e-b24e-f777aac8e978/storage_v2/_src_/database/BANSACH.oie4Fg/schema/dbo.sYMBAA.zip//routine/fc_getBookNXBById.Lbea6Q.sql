create Function [dbo].[fc_getBookNXBById](@MaSach varchar(10)) Returns nvarchar(50)
As
Begin
	Declare @NXB nvarchar(255) = null;
	Select @NXB = [dbo].fc_getNxbById(MaNXB) From Books Where MaSach = @MaSach
	return @NXB;
End
go

