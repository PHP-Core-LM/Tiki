create function [dbo].[fc_getDHbyID](@MaKH varchar(10))
returns @KetQua table(
MaHoaDon nvarchar(255),
NgayIn datetime,
TinhTrang nvarchar(255)
)
as
begin
	insert into @KetQua
		select MaHoaDon, NgayIn, [dbo].fc_getStateById(TinhTrang) from HoaDon where MaTaiKhoan=@MaKH
	return;
end
go

