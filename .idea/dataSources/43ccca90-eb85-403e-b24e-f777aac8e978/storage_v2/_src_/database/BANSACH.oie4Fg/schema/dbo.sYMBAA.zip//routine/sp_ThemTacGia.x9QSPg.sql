
CREATE Procedure sp_ThemTacGia
	@MaTacGia varchar(10) output,
	@TacGia nvarchar(50)
As
Begin
	Declare @CountRow int;

	-->Đếm số lượng dòng đã có trong bảng
	Select @CountRow = COUNT(MaTacGia) From TacGia;

	-->Tạo Mã thể loại mới theo số lượng dòng đã có
	Select @MaTacGia = 'au' + RIGHT('00000' + CAST((@CountRow + 1) As varchar(5)), 5);

	-->Thêm thể loại mới vào bảng
	Insert Into TacGia Values(@MaTacGia, @TacGia);
End
go

