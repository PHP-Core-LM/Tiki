CREATE Procedure sp_ThemNXB
	@MaNXB varchar(10) output,
	@TenNXB nvarchar(50)
As
Begin
	Declare @CountRow int;

	-->Đếm số lượng dòng đã có trong bảng
	Select @CountRow = COUNT(MaNXB) From NXB

	-->Tạo Mã NXB mới theo số lượng dòng đã có
	Select @MaNXB = 'nxb' + RIGHT('00000' + CAST((@CountRow + 1) As varchar(5)), 5);

	-->Thêm nxb mới vào bảng
	Insert Into NXB Values(@MaNXB, @TenNXB);
End
go

