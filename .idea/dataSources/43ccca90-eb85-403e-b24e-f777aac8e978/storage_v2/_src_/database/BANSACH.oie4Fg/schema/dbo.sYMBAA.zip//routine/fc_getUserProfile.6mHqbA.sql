CREATE function [dbo].[fc_getUserProfile](@UserName varchar(10))
returns @KetQua table(
TenDangNhap varchar(10),
TenTaiKhoan nvarchar(255),
Chucvu nvarchar(255),
GioiTinh nvarchar(4),
NgaySinh date,
DiaChi nvarchar(255),
SDT nvarchar(11),
Email varchar(50)
)
as
begin
	insert into @KetQua
		select TenDangNhap, TenTaiKhoan,[dbo].fc_getRollById(MaChucVu),[dbo].fc_getSex(GioiTinh), NgaySinh,DiaChi,SDT, Email from CT_Account where TenDangNhap=@UserName
	return;
end
go

