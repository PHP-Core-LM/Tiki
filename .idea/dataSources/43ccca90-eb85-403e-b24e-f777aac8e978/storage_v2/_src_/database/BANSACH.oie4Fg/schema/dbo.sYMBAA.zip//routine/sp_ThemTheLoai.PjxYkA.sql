
CREATE Procedure sp_ThemTheLoai
	@MaTheLoai varchar(10) output,
	@TheLoai nvarchar(50)
As
Begin
	Declare @CountRow int;

	-->Đếm số lượng dòng đã có trong bảng
	Select @CountRow = COUNT(MaTheLoai) From TheLoai

	-->Tạo Mã thể loại mới theo số lượng dòng đã có
	Select @MaTheLoai = 'type' + RIGHT('00000' + CAST((@CountRow + 1) As varchar(5)), 5);

	-->Thêm thể loại mới vào bảng
	Insert Into TheLoai Values(@MaTheLoai, @TheLoai);
End
go

