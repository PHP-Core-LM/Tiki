CREATE function [dbo].[fc_getAllDH]()
returns @KetQua table(
MaHoaDon nvarchar(255),
MaTaikhoan varchar(10),
TenNguoiMua ntext,
SDT nvarchar(11),
TinhTrang nvarchar(255)
)
as
begin
	insert into @KetQua
		select MaHoaDon, MaTaiKhoan, TenNguoiMua, SDT, [dbo].fc_getStateById(TinhTrang) from HoaDon
	return;
end
go

