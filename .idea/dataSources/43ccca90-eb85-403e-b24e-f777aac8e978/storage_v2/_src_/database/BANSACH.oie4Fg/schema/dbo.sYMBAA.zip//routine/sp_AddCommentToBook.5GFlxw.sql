
CREATE Procedure [dbo].[sp_AddCommentToBook](@TenDangNhap varchar(10), @TenTaiKhoan nvarchar(255), @MaSach varchar(10), @NoiDung ntext, @DanhGia int)
As
Begin
	Declare @ThoiGian DateTime = GETDATE();
	If (@TenDangNhap Is Null)
		Insert Into Comment Values (NULL, @TenTaiKhoan, @MaSach, @NoiDung, @ThoiGian, @DanhGia);
	Else
		Insert Into Comment Values (@TenDangNhap, NULL, @MaSach, @NoiDung, @ThoiGian, @DanhGia);
	Return;
End
go

