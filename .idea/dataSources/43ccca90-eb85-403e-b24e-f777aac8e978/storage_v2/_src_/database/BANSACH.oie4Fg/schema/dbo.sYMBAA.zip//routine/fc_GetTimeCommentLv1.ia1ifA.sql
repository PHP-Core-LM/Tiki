
CREATE Function [dbo].[fc_GetTimeCommentLv1](@ThoiGianBinhLuan datetime) Returns int
As
Begin
	Declare @KhoangCach int, @ThoiGianHienTai datetime;
	Select @KhoangCach = ABS(DATEDIFF(Day, @ThoiGianBinhLuan, GETDATE()));
	Return @KhoangCach;
End
go

