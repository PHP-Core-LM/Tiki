
CREATE Function [dbo].[fc_getRollById](@MaChucVu varchar(10)) Returns nvarchar(255)
As
Begin
	Declare @TenChucVu nvarchar(255) = null;
	Select @TenChucVu = TenChucVu From ChucVu Where MaChucVu = @MaChucVu
	return @TenChucVu;
End
go

