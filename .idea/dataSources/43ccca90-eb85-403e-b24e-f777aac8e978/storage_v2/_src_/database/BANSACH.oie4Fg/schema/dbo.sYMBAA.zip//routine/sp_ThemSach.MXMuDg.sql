CREATE Procedure [dbo].[sp_ThemSach]
	@MaSach varchar(10),
	@TenSach nvarchar(255),
	@Gia int,
	@MaTheLoai varchar(10),
	@MaNXB varchar(10),
	@MaTacGia varchar(10),
	@MoTa ntext
As
Begin
	Insert Into Books 
		Values(@MaSach, @TenSach, @Gia, @MaTheLoai, @MaNXB, @MaTacGia, @MoTa, 5.0);
End
go

