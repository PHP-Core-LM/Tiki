CREATE view V_RandBook
as
select TOP(50) MaSach, TenSach, GiaBan, MaTheLoai, MaNXB, MaTacGia, MoTa, DanhGia from Books ORDER BY NEWID();

go

