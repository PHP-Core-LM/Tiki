CREATE Function [dbo].[fc_getBookPriceById](@MaSach varchar(10)) Returns int
As
Begin
	Declare @GiaBan int;
	Select @GiaBan = GiaBan From Books Where MaSach = @MaSach
	return @GiaBan;
End
go

