
Create Function fc_CheckAccount(@TenDangNhap varchar(10)) Returns Bit
As
Begin
	Declare @Result bit;
	If (Exists (Select * From Account acc Where acc.TenDangNhap = @TenDangNhap))
		Set @Result = 0;
	Else
		Set @Result = 1;
	Return @Result;
End
go

