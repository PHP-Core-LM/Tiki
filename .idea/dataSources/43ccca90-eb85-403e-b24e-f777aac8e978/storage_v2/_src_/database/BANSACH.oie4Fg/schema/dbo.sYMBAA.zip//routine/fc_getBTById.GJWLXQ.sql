CREATE function [dbo].[fc_getBTById](@MaTin varchar(10))
returns @KetQua table(
MaTin int,
NoiDung nvarchar(MAX),
Anh varchar(MAX),
TieuDe nvarchar(MAX)
)
as
begin
	insert into @KetQua
		select * from BangTin where @MaTin=MaTin
	return;
end
go

