create proc UpUserInfo(
@Makh varchar(10),
@TenTaiKhoan nvarchar(255),
@Sex varchar(5),
@Ngaysinh date,
@Diachi varchar(255),
@Email varchar(50),
@SDT varchar(11)
)
as
Begin
	declare @set bit;
	if(@Sex='Nam')
		set @set=1
	else
		set @set=0

	Update CT_Account set TenTaiKhoan=@TenTaiKhoan, GioiTinh=@Set, NgaySinh=@Ngaysinh,DiaChi=@Diachi,
	Email=@Email, SDT=@SDT where TenDangNhap=@Makh
End
go

