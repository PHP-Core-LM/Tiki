create Function [dbo].[fc_getBookDecrById](@MaSach varchar(10)) Returns nvarchar(max)
As
Begin
	Declare @MoTa nvarchar(max);
	Select @MoTa = MoTa From Books Where MaSach = @MaSach
	return @MoTa;
End
go

