CREATE proc [dbo].[sp_HuyDon]
	@MaHoaDon varchar(10)
as
begin
	declare @TinhTrang varchar(10)
	select @TinhTrang= TinhTrang from HoaDon where MaHoaDon=@MaHoaDon
	if(@TinhTrang='TT1')
		delete from CT_HoaDon
		where MaHoaDon=@MaHoaDon
		delete from HoaDon
		where MaHoaDon=@MaHoaDon
		
end
go

