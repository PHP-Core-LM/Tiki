CREATE proc [dbo].[searchbook]
	@chuoicantim nvarchar(255)
as
begin
	select * from Books where TenSach like '%'+@chuoicantim+'%' or dbo.fuChuyenCoDauThanhKhongDau(TenSach) like '%'+@chuoicantim+'%'
end
go

