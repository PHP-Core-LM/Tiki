CREATE view [dbo].[v_TOPBan]
as
	select TOP(255) MaSach, COUNT(MaSach) SL from CT_HoaDon group by MaSach order by SL DESC;

go

