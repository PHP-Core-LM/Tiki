create Function [dbo].[fc_getBookNameById](@MaSach varchar(10)) Returns nvarchar(255)
As
Begin
	Declare @TenSach nvarchar(255) = null;
	Select @TenSach = TenSach From Books Where MaSach = @MaSach
	return @TenSach;
End
go

