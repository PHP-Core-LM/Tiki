CREATE Procedure sp_ChinhSuaAnh
	@MaAnh varchar(10),
	@MaSach varchar(10),
	@DuongDan varchar(50)
As
Begin
	Update [Image] Set DuongDan = @DuongDan
		Where @MaAnh = MaAnh And @MaSach = MaSach;
End
go

