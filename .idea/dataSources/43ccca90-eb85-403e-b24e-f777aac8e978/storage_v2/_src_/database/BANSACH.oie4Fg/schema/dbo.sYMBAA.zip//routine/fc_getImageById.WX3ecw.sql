-->Lấy đường dẫn của hình ảnh
CREATE Function fc_getImageById(@MaAnh varchar(10), @MaSach varchar(10)) Returns @KetQua Table (
	MaAnh varchar(10),
	DuongDan varchar(50)
)
As
Begin
	If (@MaAnh Is Null)
		Insert Into @KetQua
			Select MaAnh, DuongDan From [Image] Where @MaSach = MaSach
	Else if (@MaSach Is Null)
		Insert into @KetQua
			Select MaAnh, DuongDan From [Image] Where @MaAnh = MaAnh
	Else
		Insert into @KetQua
			Select MaAnh, DuongDan From [Image] Where @MaAnh = MaAnh And @MaSach = MaSach
	Return;
End
go

