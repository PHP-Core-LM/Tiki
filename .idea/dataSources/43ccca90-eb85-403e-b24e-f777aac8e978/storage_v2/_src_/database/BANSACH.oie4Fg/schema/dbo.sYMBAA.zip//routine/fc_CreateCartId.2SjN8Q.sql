CREATE Function [dbo].[fc_CreateCartId]() returns varchar(10)
As
Begin
	Declare @MaHoaDon varchar(10), @Count int = 0;
	Select @Count = COUNT(MaHoadon) From HoaDon
	Set @MaHoaDon = 'HD' + RIGHT('0000' + Convert(varchar, @Count + 1), 4);
	return @MaHoaDon;
End
go

